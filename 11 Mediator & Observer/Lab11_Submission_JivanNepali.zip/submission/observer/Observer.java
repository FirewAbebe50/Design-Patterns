package cs525.labs.observer;

import java.util.List;

public interface Observer {

	void update(List<String> names);
}
