package cs525.labs.mediator;

public enum Color {

	BLACK, WHITE, NOCLR
}
