package interpretorPattern.expression;

public interface Expression {

    public abstract int interpret();

}
