package visitorPattern;

public enum Side {
	RIGHT, 
        LEFT, 
        NONE
}
