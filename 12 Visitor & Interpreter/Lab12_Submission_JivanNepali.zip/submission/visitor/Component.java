package visitorPattern;

public interface Component {

	public void accept(NodeVisitor visitor);
}
